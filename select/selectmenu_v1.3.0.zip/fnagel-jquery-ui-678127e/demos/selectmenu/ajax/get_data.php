<?php
// echo $_GET['get_data'];
?>

<label for="speedB">Select an Address:</label>
<select name="speedB" id="speedB">
  <option value="1">John Doe</option>
  <option value="3">Joseph Doe</option>
  <option value="4">Mad Doe Kiiid</option>
</select>
          

        